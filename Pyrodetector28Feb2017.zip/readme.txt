Alexander Bondarenko's dissertation

pyrodetector.com

or

sites.google.com/site/pyrodetector


8*8*8*